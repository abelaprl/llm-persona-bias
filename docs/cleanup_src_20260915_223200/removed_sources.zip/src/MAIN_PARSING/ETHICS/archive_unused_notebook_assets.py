"""Plan and validate a recoverable cleanup of the three ETHICS notebook bundles."""

import base64
import hashlib
import json
from pathlib import Path
import sys
import nbformat
import pandas as pd
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parents[3]
DOMAINS = ['gender', 'religion', 'regional']
PLAN = ROOT / 'docs/ethics_archive_plan_20260910.json'
ARCHIVE = 'archive/20260910_cleanup'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def plan():
    if PLAN.exists():
        raise FileExistsError(f'Keep the existing recovery record intact: {PLAN}')
    data = {'workspace': str(ROOT), 'bundles': [], 'moves': [], 'files': []}
    for domain in DOMAINS:
        folder = ROOT / 'notebooks' / domain / 'ethics accuracy analysis'
        notebook = next(folder.glob('*Lengkap.ipynb'))
        nb = nbformat.read(notebook, as_version=4)
        source = '\n'.join(c.source for c in nb.cells)
        embedded = {hashlib.sha256(base64.b64decode(o.data['image/png'])).hexdigest()
                    for c in nb.cells for o in c.get('outputs', []) if 'image/png' in o.get('data', {})}
        active, unused = [], []
        for path in sorted((folder / 'figures').glob('*.png')):
            (active if path.stem in source or sha(path) in embedded else unused).append(path.stem)
        bundle = {'domain': domain, 'folder': str(folder), 'notebook': str(notebook),
                  'active_stems': active, 'archived_stems': unused}
        data['bundles'].append(bundle)
        candidates = []
        for stem in unused:
            candidates.extend(folder / 'figures' / f'{stem}.{suffix}' for suffix in ['png', 'svg'])
        if domain == 'gender':
            for name in ['revision_all_subsets_v2', 'per_subset/archive_v1']:
                assert name not in source
                path = folder / name
                if path.exists():
                    candidates.append(path)
        for path in candidates:
            assert path.exists()
            target = folder / ARCHIVE / path.relative_to(folder)
            assert not target.exists(), f'Archive collision: {target}'
            data['moves'].append({'source': str(path), 'destination': str(target), 'bundle': str(folder)})
            for leaf in (sorted(p for p in path.rglob('*') if p.is_file()) if path.is_dir() else [path]):
                new = target / leaf.relative_to(path) if path.is_dir() else target
                data['files'].append({'source': str(leaf), 'destination': str(new), 'sha256': sha(leaf)})
        print(f"[PLAN] {domain}: {len(active)} active, {len(unused)} unused figure pairs", flush=True)
    data['protected_tables'] = {str(p): sha(p) for b in data['bundles']
                                for p in (Path(b['folder']) / 'tables').glob('*.csv')}
    PLAN.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f"[PLAN] {len(data['moves'])} moves, {len(data['files'])} files; {PLAN}", flush=True)


def finalize():
    data = json.loads(PLAN.read_text(encoding='utf-8'))
    mapping = {f['source']: f['destination'] for f in data['files']}
    for item in data['files']:
        assert not Path(item['source']).exists()
        assert sha(Path(item['destination'])) == item['sha256']
    for b in data['bundles']:
        folder = Path(b['folder'])
        index_path = folder / 'output_index.csv'
        index = pd.read_csv(index_path)
        for row_index, row in index.iterrows():
            relative = row.get('relative_path', row['file'])
            path = (folder / str(relative)).resolve()
            if str(path) in mapping:
                target = Path(mapping[str(path)])
                new_relative = target.relative_to(folder).as_posix()
                if 'relative_path' in index.columns:
                    index.loc[row_index, 'relative_path'] = new_relative
                if 'path' in index.columns:
                    index.loc[row_index, 'path'] = str(target)
                if '/' in str(row['file']):
                    index.loc[row_index, 'file'] = new_relative
                index.loc[row_index, 'kind'] = 'archived_figure'
        index.to_csv(index_path, index=False)
        manifest_path = folder / 'bundle_manifest.json'
        manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        active_files = [f'{stem}.{suffix}' for stem in b['active_stems'] for suffix in ['png', 'svg']]
        for key in ['active_figure_files', 'parent_figure_files', 'figure_files']:
            if key in manifest:
                prefix = 'figures/' if any(str(x).startswith('figures/') for x in manifest[key]) else ''
                manifest[key] = [prefix + name for name in active_files]
        manifest['active_notebook'] = Path(b['notebook']).name
        manifest['active_parent_figure_count'] = len(b['active_stems'])
        manifest['archive_directory'] = ARCHIVE if b['archived_stems'] else None
        manifest['archive_plan'] = str(PLAN.relative_to(ROOT)).replace('\\', '/')
        if 'figure_count' in manifest:
            manifest['figure_count'] = len(active_files)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
        # Add an inventory beside the metadata, without producing another notebook.
        inventory = [{'notebook': Path(b['notebook']).name, 'figure': f'figures/{name}', 'status': 'active'}
                     for name in active_files]
        pd.DataFrame(inventory).to_csv(folder / 'active_figures.csv', index=False)
        notebook_path = Path(b['notebook'])
        nb = nbformat.read(notebook_path, as_version=4)
        if b['domain'] == 'religion':
            for cell in nb.cells:
                cell.source = cell.source.replace("f'01_ethics_religion_{subset}_performance_by_persona'", "f'01_{subset}_performance_by_persona'")
                cell.source = cell.source.replace("f'02_ethics_religion_{subset}_status_by_persona'", "f'02_{subset}_status_by_persona'")
                cell.source = cell.source.replace('if path.is_file(): display(Image(filename=str(path), width=1450))',
                    'assert path.is_file(), str(path)\n        display(Image(filename=str(path), width=1450))')
        if b['domain'] == 'gender':
            for cell in nb.cells:
                cell.source = cell.source.replace('3 chart gabungan, 13 chart pendukung, dan 8 chart detail ditampilkan.',
                                                   '5 chart utama, 13 chart pendukung, dan 8 chart detail ditampilkan.')
        print(f"[VERIFY] Executing {notebook_path.name}", flush=True)
        NotebookClient(nb, timeout=600, kernel_name='python3',
                       resources={'metadata': {'path': str(folder)}}).execute()
        assert not any(o.output_type == 'error' for c in nb.cells for o in c.get('outputs', []))
        nbformat.write(nb, notebook_path)
        assert {p.stem for p in (folder / 'figures').glob('*.png')} == set(b['active_stems'])
        print(f"[PASS] {b['domain']}: notebook runs; {len(active_files)} active PNG/SVG assets", flush=True)
    assert all(sha(Path(p)) == value for p, value in data['protected_tables'].items())
    print(f"[PASS] {len(data['files'])} archived files verified by SHA256; numeric tables unchanged", flush=True)


if __name__ == '__main__':
    finalize() if '--finalize' in sys.argv else plan()
