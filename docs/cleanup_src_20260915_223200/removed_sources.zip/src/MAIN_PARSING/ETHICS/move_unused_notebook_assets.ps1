$ErrorActionPreference = 'Stop'
$workspaceRoot = 'D:\TugasAkhir'
$planPath = Join-Path $workspaceRoot 'docs\ethics_archive_plan_20260910.json'
$plan = Get-Content -LiteralPath $planPath -Raw -Encoding UTF8 | ConvertFrom-Json
$allowedBundles = @('gender', 'religion', 'regional') | ForEach-Object {
    [IO.Path]::GetFullPath((Join-Path $workspaceRoot "notebooks\$_\ethics accuracy analysis"))
}

# Resolve and validate every source/destination before moving any file or directory.
foreach ($move in $plan.moves) {
    $bundlePath = [IO.Path]::GetFullPath($move.bundle)
    if ($bundlePath -notin $allowedBundles) { throw "Unexpected bundle: $bundlePath" }
    $sourcePath = (Resolve-Path -LiteralPath $move.source).Path
    $targetPath = [IO.Path]::GetFullPath($move.destination)
    $archivePrefix = Join-Path $bundlePath 'archive\20260910_cleanup\'
    if (-not $sourcePath.StartsWith($bundlePath + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Source outside bundle: $sourcePath" }
    if (-not $targetPath.StartsWith($archivePrefix, [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside archive: $targetPath" }
    if (Test-Path -LiteralPath $targetPath) { throw "Destination already exists: $targetPath" }
}
foreach ($file in $plan.files) {
    if ((Get-FileHash -LiteralPath $file.source -Algorithm SHA256).Hash -ne $file.sha256) { throw "Changed since plan: $($file.source)" }
}
foreach ($move in $plan.moves) {
    $parentPath = Split-Path -Parent $move.destination
    [void][IO.Directory]::CreateDirectory($parentPath)
    Move-Item -LiteralPath $move.source -Destination $move.destination
    Write-Output "[ARCHIVE] $($move.source)"
}
foreach ($file in $plan.files) {
    if ((Get-FileHash -LiteralPath $file.destination -Algorithm SHA256).Hash -ne $file.sha256) { throw "Archive hash mismatch: $($file.destination)" }
}
Write-Output "[PASS] All archived file hashes match; no files deleted."
