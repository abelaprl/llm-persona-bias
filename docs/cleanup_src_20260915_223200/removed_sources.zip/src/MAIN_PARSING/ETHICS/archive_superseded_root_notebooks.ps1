$ErrorActionPreference = 'Stop'
$notebookRoot = [IO.Path]::GetFullPath('D:\TugasAkhir\notebooks')
$archiveRoot = Join-Path $notebookRoot 'archive\20260910_superseded_notebooks'
$relativeNames = @(
    'linguistic_marker_gender_gsm8k_bab4_visual_revision_v2.ipynb',
    'religion\linguistic_marker_religion_ethics_bab4_visual_v1.ipynb',
    'religion\linguistic_marker_religion_ethics_bab4_visual_v1_1.ipynb',
    'religion\linguistic_marker_religion_ethics_atlas_v2_0_1_candidate_20260827.ipynb',
    'religion\linguistic_marker_religion_ethics_thesis_v2_0_1_candidate_20260827.ipynb',
    'religion\ETHICS_Religion_Persona_Publication_Analysis_v4_Accuracy_Persona_First.ipynb',
    'religion\ETHICS_Religion_Persona_Publication_Analysis_v4_GSM8K_Style.ipynb'
)
$records = foreach ($relative in $relativeNames) {
    $sourcePath = (Resolve-Path -LiteralPath (Join-Path $notebookRoot $relative)).Path
    $destinationPath = [IO.Path]::GetFullPath((Join-Path $archiveRoot $relative))
    if (-not $sourcePath.StartsWith($notebookRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Source outside notebooks: $sourcePath" }
    if (-not $destinationPath.StartsWith($archiveRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Target outside archive: $destinationPath" }
    if (Test-Path -LiteralPath $destinationPath) { throw "Archive collision: $destinationPath" }
    if ([IO.Path]::GetExtension($sourcePath) -ne '.ipynb') { throw "Unexpected file type: $sourcePath" }
    [PSCustomObject]@{
        source = $sourcePath
        destination = $destinationPath
        sha256 = (Get-FileHash -LiteralPath $sourcePath -Algorithm SHA256).Hash
    }
}
[void][IO.Directory]::CreateDirectory($archiveRoot)
$indexPath = Join-Path $archiveRoot 'archive_index.csv'
if (Test-Path -LiteralPath $indexPath) { throw 'Do not overwrite the recovery index.' }
$records | Export-Csv -LiteralPath $indexPath -NoTypeInformation -Encoding UTF8
foreach ($record in $records) {
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $record.destination))
    Move-Item -LiteralPath $record.source -Destination $record.destination
    if ((Get-FileHash -LiteralPath $record.destination -Algorithm SHA256).Hash -ne $record.sha256) { throw "Hash mismatch: $($record.destination)" }
    Write-Output "[ARCHIVE] $($record.source)"
}
Write-Output '[PASS] Seven notebooks archived, SHA256 unchanged; no figures or source data moved.'
