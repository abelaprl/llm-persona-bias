$ErrorActionPreference = 'Stop'
$notebookRoot = [IO.Path]::GetFullPath('D:\TugasAkhir\notebooks')
$archiveRoot = Join-Path $notebookRoot 'archive\20260910_regional_ethics'
$relativeNames = @(
    'regional\ETHICS_Regional_Cultural_Linguistic_Markers_Analysis_v1.ipynb',
    'regional\linguistic_marker_regional_cultural_ethics_bab4_visual_v1.ipynb',
    'regional cultural\linguistic_marker_regional_cultural_ethics_bab4_visual_v1.ipynb',
    'regional\ETHICS_Regional_Cultural_Persona_Publication_Analysis_v4_Accuracy_Region_First.ipynb',
    'regional\ethics accuracy analysis_render_failed_20260907_0011'
)
$activeNames = @(
    'regional\linguistic_marker_regional_cultural_ethics_thesis_v2_0_1_candidate_20260828.ipynb',
    'regional\linguistic_marker_regional_cultural_ethics_atlas_v2_0_1_candidate_20260828.ipynb',
    'regional\ethics accuracy analysis\ETHICS_Regional_Cultural_Accuracy_Analysis_Lengkap.ipynb'
)
$protected = foreach ($name in $activeNames) {
    $path = Join-Path $notebookRoot $name
    [PSCustomObject]@{ path=$path; sha256=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
}
$moves = foreach ($name in $relativeNames) {
    $source = (Resolve-Path -LiteralPath (Join-Path $notebookRoot $name)).Path
    $destination = [IO.Path]::GetFullPath((Join-Path $archiveRoot $name))
    $withinRegional = $source.StartsWith((Join-Path $notebookRoot 'regional\'), [StringComparison]::OrdinalIgnoreCase)
    $withinCultural = $source.StartsWith((Join-Path $notebookRoot 'regional cultural\'), [StringComparison]::OrdinalIgnoreCase)
    if (-not ($withinRegional -or $withinCultural)) { throw "Source outside intended folders: $source" }
    if (-not $destination.StartsWith($archiveRoot + '\', [StringComparison]::OrdinalIgnoreCase)) { throw "Invalid archive path: $destination" }
    if (Test-Path -LiteralPath $destination) { throw "Archive collision: $destination" }
    [PSCustomObject]@{source=$source; destination=$destination}
}
$records = foreach ($move in $moves) {
    $item = Get-Item -LiteralPath $move.source
    $files = if ($item.PSIsContainer) { Get-ChildItem -LiteralPath $item.FullName -Recurse -File } else { @($item) }
    foreach ($file in $files) {
        $destination = if ($item.PSIsContainer) {
            Join-Path $move.destination $file.FullName.Substring($item.FullName.Length + 1)
        } else { $move.destination }
        [PSCustomObject]@{source=$file.FullName; destination=$destination; sha256=(Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash}
    }
}
$indexPath = Join-Path $archiveRoot 'archive_index.csv'
if (Test-Path -LiteralPath $indexPath) { throw 'Keep the recovery index intact.' }
[void][IO.Directory]::CreateDirectory($archiveRoot)
$records | Export-Csv -LiteralPath $indexPath -NoTypeInformation -Encoding UTF8
foreach ($move in $moves) {
    [void][IO.Directory]::CreateDirectory((Split-Path -Parent $move.destination))
    Move-Item -LiteralPath $move.source -Destination $move.destination
    Write-Output "[ARCHIVE] $($move.source)"
}
foreach ($record in $records) {
    if ((Get-FileHash -LiteralPath $record.destination -Algorithm SHA256).Hash -ne $record.sha256) { throw "Archive hash mismatch: $($record.destination)" }
    if (Test-Path -LiteralPath $record.source) { throw "Source still present: $($record.source)" }
}
foreach ($record in $protected) {
    if ((Get-FileHash -LiteralPath $record.path -Algorithm SHA256).Hash -ne $record.sha256) { throw "Active notebook changed: $($record.path)" }
}
Write-Output "[PASS] $($records.Count) files archived; all hashes match; three active notebooks unchanged."
